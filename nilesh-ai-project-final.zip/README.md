# Nilesh AI Assistant

आपकी फोटो `public/profile.jpg` में पहले से लगी हुई है।

## चलाने का तरीका
1. Node.js install करें।
2. Terminal में इस folder में जाएँ।
3. `npm install`
4. `.env.example` की copy बनाकर `.env` नाम दें।
5. `.env` में अपनी OpenAI API key डालें।
6. `npm start`
7. Browser में `http://localhost:3000` खोलें।

API key को कभी `index.html` में न डालें और GitHub पर `.env` upload न करें।
