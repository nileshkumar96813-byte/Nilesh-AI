import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const instructions = `
You are Nilesh AI, a friendly website assistant.
Speak in Hindi, Hinglish or English according to the user's language.
Help with English conversation/practice, translation, coding, web development,
CV writing, study and general questions. Be clear and concise.
Never reveal API keys, passwords or server secrets.
`;

app.get("/api/health", (req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({
        error: "AI अभी चालू नहीं है। Server की .env file में OPENAI_API_KEY लगाइए।"
      });
    }

    const messages = Array.isArray(req.body?.messages)
      ? req.body.messages
          .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
          .slice(-20)
          .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }))
      : [];

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions,
      input: messages
    });

    res.json({ reply: response.output_text || "माफ कीजिए, अभी जवाब नहीं मिल पाया।" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI से जवाब नहीं मिला। API key और server configuration जांचें।" });
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`Nilesh AI running on http://localhost:${PORT}`));
